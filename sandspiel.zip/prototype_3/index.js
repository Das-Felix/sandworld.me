const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");

var pixelSize = 5;
var refreshRate = 10;
var windowWithInPixels = 340;
var windowHeightInPixels = 200;
var chunkSize = 10;
var debugging = true;
var width = 1700;
var height = 1000;

//fps
var filterStrength = 20;
var frameTime = 0, lastLoop = new Date, thisLoop;


//Pixel
var grid = [];
var pixelData = [];


//Creating Grid Array

for(var i = 0; i < windowHeightInPixels; i++) {
    var gridRow = [];

    for(var j = 0; j < windowWithInPixels; j++) {
        gridRow.push(0);
    }

    grid.push(gridRow);
}

console.log(grid)

var pixelCount = 0;


//Fix:
//Auch die X-Kordinate vorher füllen und dann anhand von Strings den Typ des Pixels speichern
//Also das Array Direkt ganz befüllen und nicht nur auf der y Achese

function updatePixels() {
    //Simulating
    //context.clearRect(0, 0, canvas.width, canvas.height);

    for(var y = grid.length - 2; y > 1; y--) {

        for(var x = 0; x < grid[y].length; x++) {
            
            //Check if there is a pixel, otherwise continue loop
            if(grid[y][x] == 0) continue;

            //Sand
            if(grid[y][x] == 1) {


                if(grid[(y + 1)][x] == 0) {
                    grid[y][x] = 0;
                    grid[(y + 1)][x] = 1;

                    clearPixel(x, y)
                    drawPixel(x, (y + 1), "#e8d7a7");
                    continue;
                }

                if(grid[(y + 1)][(x + 1)] == 0) {
                    grid[y][x] = 0;
                    grid[(y + 1)][(x + 1)] = 1;

                    clearPixel(x, y);
                    drawPixel((x + 1), (y + 1), "#e8d7a7");
                    continue;
                }

                if(grid[(y + 1)][(x - 1)] == 0) {
                    grid[y][x] = 0;
                    grid[(y + 1)][(x - 1)] = 1;

                    clearPixel(x, y);
                    drawPixel((x - 1), (y + 1), "#e8d7a7");
                    continue;
                }
            }

            if(grid[y][x] == 2) {


                if(grid[(y + 1)][x] == 0) {
                    grid[y][x] = 0;
                    grid[(y + 1)][x] = 2;

                    clearPixel(x, y)
                    drawPixel(x, (y + 1), "#0964f7");
                    continue;
                }

                if(grid[(y)][(x + 1)] == 0) {
                    grid[y][x] = 0;
                    grid[(y)][(x + 1)] = 2;

                    clearPixel(x, y);
                    drawPixel((x + 1), (y), "#0964f7");
                    continue;
                }

                if(grid[(y)][(x - 1)] == 0) {
                    grid[y][x] = 0;
                    grid[(y)][(x - 1)] = 2;

                    clearPixel(x, y);
                    drawPixel((x - 1), (y), "#0964f7");
                    continue;
                }
            }


        }
    }

    //Framerate
    var thisFrameTime = (thisLoop=new Date) - lastLoop;
    frameTime+= (thisFrameTime - frameTime) / filterStrength;
    lastLoop = thisLoop;

    //drawArray();

    document.getElementById("pixelCount").innerHTML = pixelCount;
} 

function drawArray() {

    context.clearRect(0, 0, canvas.width, canvas.height);

    for(var y = 0; y < grid.length; y++) {
        grid[y].forEach(x => {
            drawPixel(x, y);
        });
    }
}


function drawPixel(x, y, color) {
    context.fillStyle = color || "#e0988d";
  	context.fillRect(x*pixelSize, y*pixelSize, pixelSize, pixelSize);
}

function clearPixel(x, y) {
    context.clearRect(x*pixelSize, y*pixelSize, pixelSize, pixelSize);
}

function createPixel(x, y, id) {
    grid[y][x] = document.getElementById("materialid").value;
    pixelCount++;
}


//Paint

var paintSize = 12;

canvas.addEventListener("mousedown", (event) => {
    const boundingRect = canvas.getBoundingClientRect();

    const scaleX = canvas.width / Math.ceil(window.devicePixelRatio) / boundingRect.width;
    const scaleY = canvas.height / Math.ceil(window.devicePixelRatio) / boundingRect.height;

    const canvasLeft = (event.clientX - boundingRect.left) * scaleX;
    const canvasTop = (event.clientY - boundingRect.top) * scaleY;

    const realX = Math.min(Math.floor(canvasLeft), width - 1);
    const realY = Math.min(Math.floor(canvasTop), height - 1);
    
    const x = Math.round(realX / pixelSize, 0);
    const y = Math.round(realY / pixelSize, 0);



    for(var i = x-paintSize/2;i < x+paintSize/2; i++) {
        for(var j = y-paintSize/2;j < y+paintSize/2; j++) {
            createPixel(i, j);
            console.log("A")
        }
    }
});


//Running update
setInterval(updatePixels, refreshRate);

var fpsOut = document.getElementById('fps');
setInterval(function(){
  fpsOut.innerHTML = (1000/frameTime).toFixed(1) + " fps";
},1000);